#!/bin/bash

WORKDIR=$PWD

function configure_container_runtimes {

cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF

sudo modprobe overlay
sudo modprobe br_netfilter

# sysctl params required by setup, params persist across reboots
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF

# Apply sysctl params without reboot
sudo sysctl --system

}


function install_container_runtimes_cri-o {

if ! [ -f "cri-o.amd64.v1.28.2.tar.gz" ]; then
    curl -O https://storage.googleapis.com/cri-o/artifacts/cri-o.amd64.v1.28.2.tar.gz
fi

rm -rf cri-o \
  && tar zxf cri-o.amd64.v1.28.2.tar.gz \
  && cd cri-o \
  && sudo ../cri-o.install
cd $WORKDIR

sudo systemctl daemon-reload
sudo systemctl enable --now crio

}


function configure_swap {

sudo swapoff -a
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

}


function install_kubeadm_kubelet_kubectl {

# Set SELinux in permissive mode (effectively disabling it)
sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config

# This overwrites any existing configuration in /etc/yum.repos.d/kubernetes.repo
cat <<EOF | sudo tee /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.28/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.28/rpm/repodata/repomd.xml.key
exclude=kubelet kubeadm kubectl cri-tools kubernetes-cni
EOF

sudo yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
sudo systemctl enable --now kubelet

}


function install_tc {

if ! command -v tc; then
    sudo yum install -y iproute-tc
fi

}


configure_container_runtimes
install_container_runtimes_cri-o
configure_swap
install_kubeadm_kubelet_kubectl
install_tc
